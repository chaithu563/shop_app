﻿// Default code generation is disabled for model 'C:\chaitanya\raja\myshop\shop_app\HappiPugService\HappiPugService\Models\HappiePug.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.